

for j = 1:50
temp = repmat(round(rand(10,1)),1,10);
temp = round(rand(10,10));
temp = repmat(temp,1,1,3);
I = imresize(temp,[227,227]);
imwrite(I,[num2str(j),'.jpg']);
end


